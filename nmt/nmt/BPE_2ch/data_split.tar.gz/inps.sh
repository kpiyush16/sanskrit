subword-nmt learn-bpe -s 22 < combined_ipop.txt > c22.code
subword-nmt apply-bpe -c c22.code < train_input.txt > train_BPE.src
subword-nmt apply-bpe -c c22.code < train_output.txt > train_BPE.trg
subword-nmt apply-bpe -c c22.code < valid_output.txt > valid_BPE.trg
subword-nmt apply-bpe -c c22.code < valid_input.txt > valid_BPE.src
subword-nmt apply-bpe -c c22.code < test_input.txt > test_BPE.src
subword-nmt apply-bpe -c c22.code < test_output.txt > test_BPE.trg
subword-nmt apply-bpe -c c22.code < combined_ipop.txt | subword-nmt get-vocab > vocab1.src
cut -d' ' -f1-1 vocab1.src > vocab.src
sed -i '1i<unk>\n<s>\n</s>' vocab.src
cp vocab.src vocab.trg
rm -r vocab1.src
